function predicted = classify_baluja_rowley( CLASSIFIER, x )
% function predicted = classify_baluja_rowley( CLASSIFIER, x )
% Classify a set of projected images using the baluja/rowley trained classifier
%
% Input:
%   CLASSIFIER, a structure returned by train_baluja_rowley.m
%   x, Pxn matrix (P is the number of pixels per imageand n is the number 
%      of images).

% Output:
%   predicted, the corresponding labels
%
% See also:
%   train_baluja_rowley.m

n      = size(x,2);
%P      = size(x,1);
OUTPUT = zeros(1,n);
z      = zeros(1,n);

for j=1:length(CLASSIFIER.PIXEL_PAIRS_INDICES)
  
  switch (CLASSIFIER.BASIC_CLASSIFIER_TYPE(j))
   case 1  
     z = (x(CLASSIFIER.PIXEL_PAIRS(j,1),:) > x(CLASSIFIER.PIXEL_PAIRS(j,2),:));
   case 2  
     z = (abs(x(CLASSIFIER.PIXEL_PAIRS(j,1),:) - x(CLASSIFIER.PIXEL_PAIRS(j,2),:)) <= 5);
   case 3  
     z = (abs(x(CLASSIFIER.PIXEL_PAIRS(j,1),:) - x(CLASSIFIER.PIXEL_PAIRS(j,2),:)) <= 10);
   case 4  
     z = (abs(x(CLASSIFIER.PIXEL_PAIRS(j,1),:) - x(CLASSIFIER.PIXEL_PAIRS(j,2),:)) <= 25);
   case 5  
     z = (abs(x(CLASSIFIER.PIXEL_PAIRS(j,1),:) - x(CLASSIFIER.PIXEL_PAIRS(j,2),:)) <= 50);
   case 6  
     z = (x(CLASSIFIER.PIXEL_PAIRS(j,1),:) <= x(CLASSIFIER.PIXEL_PAIRS(j,2),:));
   case 7  
     z = (abs(x(CLASSIFIER.PIXEL_PAIRS(j,1),:) - x(CLASSIFIER.PIXEL_PAIRS(j,2),:)) > 5);
   case 8  
     z = (abs(x(CLASSIFIER.PIXEL_PAIRS(j,1),:) - x(CLASSIFIER.PIXEL_PAIRS(j,2),:)) > 10);
   case 9  
     z = (abs(x(CLASSIFIER.PIXEL_PAIRS(j,1),:) - x(CLASSIFIER.PIXEL_PAIRS(j,2),:)) > 25);
   case 10 
     z = (abs(x(CLASSIFIER.PIXEL_PAIRS(j,1),:) - x(CLASSIFIER.PIXEL_PAIRS(j,2),:)) > 50);
   end;
   
   OUTPUT = OUTPUT + z.*CLASSIFIER.BASIC_CLASSIFIER_WEIGHT(j);
end

% Positive class is label 2 (female) and negative class is label 1 (male).
% NOTE that this is different to the original Baluja paper (they take the 
% >= result as female is label 0 and male is label 1).
predicted1 = (OUTPUT >= CLASSIFIER.THRESHOLD);

female_indices = find(predicted1 == 0);
male_indices   = find(predicted1 == 1);
predicted      = double(predicted1);
predicted(female_indices) = 2;
predicted(male_indices)   = 1;

