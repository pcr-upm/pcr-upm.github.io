function CLASSIFIER = train_baluja_rowley( x, y, opt)
% function CLASSIFIER = train_baluja_rowley( x, y, opt)
%
% This function performs Boosting over 10 pair-wise comparations as
% features.
%
% See paper:
%
%    "Boosting Sex Identification Performance"
%    Shumeet Baluja and Henry A. Rowley
%    IJCV, 71(1), 111-119, 2007
%
% Input:
%   x, Pxn matrix (P is the number of pixels and n is the 
%                  number of images).
%   y, the corresponding label of each image (1 male and 2 female)
%   opt, a structure that controls the behavior of the classifier
%        opt(1) is the number of weak classifiers to use.
%
% Output:
%   CLASSIFIER, a structure that is used in classify_baluja_rowley.m
%     CLASSIFIER.PIXEL_PAIRS -- Indices of pixels for each choosen 
%                               pixel pair (a Boosting iteration gives a
%                               new pixel pair and type of classifier).
%                                iteration 
%     CLASSIFIER.PIXEL_PAIRS_INDICES -- Indices each choosen 
%                               pixel pair within the nchoosek(num_pixels,
%                               2) possibles pairs.
%     CLASSIFIER.BASIC_CLASSIFIER_TYPE -- Indices of classifier type (from 
%                                         1 to 10) choosen per Boosting 
%                                         iteration
%     CLASSIFIER.BASIC_CLASSIFIER_WEIGHT -- A column vector with the 
%                                           per classifier weight
%     CLASSIFIER.THRESHOLD -- The clasifier threshold to decide for a class 
%                             or the other.
%
% See also:
%   classify_baluja_rowley.m

%P  = nchoosek(opt(2),2);  % Number of possible pixel pairs. 
n  = size(x,2);  % Number of images in the training set.

% In this matrix we mark with a one the classifiers already choosen.
%CHOOSEN_CLASSIFIERS = zeros(P, 10);

% Initialise sample weights
SAMPLE_WEIGHTS                 = ones(n, 1);
female_indices                 = find(y==2);
male_indices                   = find(y==1);
y2                             = y;
y2(female_indices)             = 0;
y2(male_indices)               = 1;
SAMPLE_WEIGHTS(female_indices) = (0.5./length(female_indices));
SAMPLE_WEIGHTS(male_indices)   = (0.5./length(male_indices));

% Run boosting loop
%CLASSIFIER_WEIGHT_SUM          = 0;
pixel_pairs                    = cell(10,1);
pixel_pairs_indices            = cell(10,1);
full_pairs                     = nchoosek(1:size(x,1), 2);

% Preparing boosting loop
YY                             = y2(:)';
z                              = zeros(1,n);
C                              = zeros(1,n);
choosen_classifier_pixel_pair  = zeros(opt(1),2);
choosen_classifier_pixel_pair_indices = zeros(opt(1),1);
choosen_classifier_type_num    = zeros(opt(1),1);
B                              = zeros(opt(1),1);
for i=1:opt(1) % opt(1) is the number of weak classifiers to retain
%  disp(['Selecting weak classifier number ' sprintf('%d...',i)]);

  % We choose **1%** of the possible classifiers to speed up training
  for k=1:10
    indices                      = randperm(nchoosek(size(x,1), 2));
    % To get **1%** of the possible classifiers we choose 0.1% of possible
    % pixel pairs per each of the 10 classifier types
    indices                      = indices(1:round(length(indices)*0.001));
 
    pixel_pairs{k,1}             = full_pairs(indices, :);
    pixel_pairs_indices{k,1}     = indices(:);
  end

  % normalise weight to sum 1
  SAMPLE_WEIGHTS = SAMPLE_WEIGHTS./sum(SAMPLE_WEIGHTS);
  
  % Compute weak classifiers classification error
  min_error           = inf;
  min_pair_index      = -1;
  min_classifier_type = 0;
  min_pixel_pair      = zeros(1,2);
  
  % Classify the images with different classifiers
  for classifier=1:10 % For each classifier 
    pairs         = pixel_pairs{classifier,1};
    pairs_indices = pixel_pairs_indices{classifier,1};
    P             = size(pairs,1);
    for j=1:P % for each pair not used with the current classifier
      switch (classifier)
        case 1  
          z = (x(pairs(j,1),:) > x(pairs(j,2),:));
        case 2  
          z = (abs(x(pairs(j,1),:) - x(pairs(j,2),:)) <= 5);
        case 3  
          z = (abs(x(pairs(j,1),:) - x(pairs(j,2),:)) <= 10);
        case 4  
          z = (abs(x(pairs(j,1),:) - x(pairs(j,2),:)) <= 25);
        case 5  
          z = (abs(x(pairs(j,1),:) - x(pairs(j,2),:)) <= 50);
        case 6  
          z = (x(pairs(j,1),:) <= x(pairs(j,2),:));
        case 7  
          z = (abs(x(pairs(j,1),:) - x(pairs(j,2),:)) > 5);
        case 8  
          z = (abs(x(pairs(j,1),:) - x(pairs(j,2),:)) > 10);
        case 9  
          z = (abs(x(pairs(j,1),:) - x(pairs(j,2),:)) > 25);
        case 10 
          z = (abs(x(pairs(j,1),:) - x(pairs(j,2),:)) > 50);
      end;
      error_j    = abs(z-YY)*SAMPLE_WEIGHTS(:);
      if (error_j < min_error)
        min_error           = error_j;
        min_pair_index      = pairs_indices(j);
        min_pixel_pair      = pairs(j,:);
        min_classifier_type = classifier;
        C                   = z;
      end
    end
  end
  
  % Choose weak classifier with lowest error: save weak classifier and 
  % weight and remove the choosen pair from the classifier type pixel_pairs
  choosen_classifier_pixel_pair(i,:)       = min_pixel_pair;
  choosen_classifier_pixel_pair_indices(i) = min_pair_index;
  choosen_classifier_type_num(i)           = min_classifier_type; % from 1 to 10
%  pixel_pairs{min_classifier_type,1}(min_pair_index,:) = []; 
%  pixel_pairs_indices{min_classifier_type,1}(min_pair_index) = [];
  
  % update sample weights: only the right classified samples changes the
  % weight.
  right_classified_indices                 = find(C == YY);   
  B(i)                                     = min_error/(1-min_error);
  SAMPLE_WEIGHTS(right_classified_indices) = B(i).*SAMPLE_WEIGHTS(right_classified_indices);
  
%  fprintf(1, '%d:(%d,%d,%d),', i, choosen_classifier_pixel_pair(i,1), ...
%                                  choosen_classifier_pixel_pair(i,2), ...
%                                  min_classifier_type);
 fprintf(1,'.');
 if (mod(i,50) == 0)
   fprintf(1,'\n');
 end
end

CLASSIFIER.PIXEL_PAIRS             = choosen_classifier_pixel_pair;
CLASSIFIER.PIXEL_PAIRS_INDICES     = choosen_classifier_pixel_pair_indices;
CLASSIFIER.BASIC_CLASSIFIER_TYPE   = choosen_classifier_type_num;
CLASSIFIER.BASIC_CLASSIFIER_WEIGHT = log(1./B);
CLASSIFIER.THRESHOLD               = 0.5*sum(CLASSIFIER.BASIC_CLASSIFIER_WEIGHT);




