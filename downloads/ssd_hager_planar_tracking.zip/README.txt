
SSD PLANE TRACKING
==================

Those are a set of matlab functions for the tracking of a planar patch 
using direct grey levels information (a.k.a. SSD).
We hage implemented the Hager and Belhumeur's Jacobian matrix factorisation 
for the translation, affine and rotation-translation-scale motion models 
appeared in the paper:

"Efficient Region Tracking With Parametric Models of Geometry and 
Illumination", Gregory D. Hager and Peter N. Belhumeur. 
IEEE TRANSACTIONS ON PATTERN ANALYSIS AND MACHINE INTELLIGENCE, 
VOL. 20, NO. 10, OCTOBER 1998

Also we have developed and implemented the Jacobian matrix factorisation
for the projective motion model:

"Real-time tracking and estimation of plane pose", 
Jos� Miguel Buenaposada Biencinto, Luis Baumela Molina. 
Proc. of International Conference on Pattern Recognition, ICPR 2002. 
Vol II, pp. 697-700, IEEE. Quebec, Canada, August 2002.


GETTING STARTED
===============

The main function is ssd_tracking. Anyway we have written a help 
function test_ssd_tracking that uses one of our image sequences.

Please address questions or comments to: josemiguel.buenaposada@urjc.es or 
lbaumela@fi.upm.es


TERMS OF USE
============

All publications and works that use this toolbox must reference the 
following paper:

"Real-time tracking and estimation of plane pose", 
Jose M. Buenaposada, Luis Baumela. 
Proc. of International Conference on Pattern Recognition, ICPR 2002. 
Vol II, pp. 697-700, IEEE. Quebec, Canada, August 2002.


(c) Jose M. Buenaposada, Luis Baumela.
Terms of use: You are free to copy,
distribute, display, and use this work, under the following
conditions. (1) You must give the original authors credit. (2) You may
not use or redistribute this work for commercial purposes. (3) You may
not alter, transform, or build upon this work. (4) For any reuse or
distribution, you must make clear to others the license terms of this
work. (5) Any of these conditions can be waived if you get permission
from the authors.

