function vparams = ssd_compute_initial_params(width, ...
                                              height, ...
					      Pinitial, ...
					      motion_model)
%
%  vparams = compute_initial_params(width, height, Pinitial, motion_model)
%
%  - width
%  - height
%  - Pinitial
%  - motion_model: 'traslation', 'rts', 'affine' or 'projective'
%
% (c) Jos� Miguel Buenaposada, Luis Baumela Molina.
% Please address questions or comments to: jmbuena@dia.fi.upm.es
% Terms of use: You are free to copy,
% distribute, display, and use this work, under the following
% conditions. (1) You must give the original authors credit. (2) You may
% not use or redistribute this work for commercial purposes. (3) You may
% not alter, transform, or build upon this work. (4) For any reuse or
% distribution, you must make clear to others the license terms of this
% work. (5) Any of these conditions can be waived if you get permission
% from the authors.


if (strcmp(motion_model,'traslation')==1)
  left       = min(min(Pinitial(:,1)));
  right      = max(max(Pinitial(:,1)));
  top        = min(min(Pinitial(:,2)));
  bottom     = max(max(Pinitial(:,2)));

  vparams    = [((right-left)/2)+left ((bottom-top)/2)+top]'; 

elseif (strcmp(motion_model,'rst')==1)

  A          = compute_affine_matrix(width, height, Pinitial);
  TR         = diag([1 1 1]);
  TR(1,3)    = width/2; 
  TR(2,3)    = height/2;
  A          = A*TR;  
  
  left       = min(min(Pinitial(:,1)));
  right      = max(max(Pinitial(:,1)));

  vparams    = [A(1,3) A(2,3) 0 (right-left)/width]'; 
  
elseif (strcmp(motion_model,'affine')==1)

  A          = compute_affine_matrix(width, height, Pinitial);
  TR         = diag([1 1 1]);
  TR(1,3)    = width/2; 
  TR(2,3)    = height/2;
  A          = A*TR;  
  
  vparams    = [A(1,3) A(2,3) A(1,1) A(2,1) A(1,2) A(2,2)]';
   
elseif (strcmp(motion_model,'projective')==1)

  H          = compute_homography(width, height, Pinitial);
  TR         = diag([1 1 1]);
  TR(1,3)    = width/2;
  TR(2,3)    = height/2;
  H          = H*TR;  
  vparams    = H(:);
  
else
  error('Motion model not valid');
end
