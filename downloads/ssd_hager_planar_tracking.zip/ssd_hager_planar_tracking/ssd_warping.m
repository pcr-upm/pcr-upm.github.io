function Iresult = ssd_warping(Isrc, Idest, Mparams, motion_model)
%
% Idest = ssd_warping(Isrc, Idest, params)
%
% Isrc the image with the cuadrilateral inside to rectify 
% into the rectangular image Idest through the motion params 
% vector.
%
% - Isrc  - Source image.
% - Idest - Rectified image.
% - motion_model: 'rst', 'affine' or 'projective'
%
% (c) Jos� Miguel Buenaposada, Luis Baumela Molina.
% Please address questions or comments to: jmbuena@dia.fi.upm.es
% Terms of use: You are free to copy,
% distribute, display, and use this work, under the following
% conditions. (1) You must give the original authors credit. (2) You may
% not use or redistribute this work for commercial purposes. (3) You may
% not alter, transform, or build upon this work. (4) For any reuse or
% distribution, you must make clear to others the license terms of this
% work. (5) Any of these conditions can be waived if you get permission
% from the authors.
%

if (~isgray(Isrc))
  error('The source image must be gray scale'); 
end

width   = size(Isrc,2); 
height  = size(Isrc,1);

widthR  = size(Idest,2);
heightR = size(Idest,1);

Iresult = zeros(size(Idest));

% Obtain all the coordinates in Idest.
[y, x] = find(Idest>=0);
    
% Compute the corresponding coordinates in Isrc
u = zeros(length(y),1);   
v = zeros(length(y),1);   
h = zeros(length(y),1);   
for i =1:length(y)
  kk   = Mparams*[x(i); y(i); 1.0];  
  u(i) = kk(1);
  v(i) = kk(2);
  h(i) = kk(3);
end

if (strcmp(motion_model, 'projective')==1) | (strcmp(motion_model, 'projective2')==1)
  u = u./h;
  v = v./h;
end
   
% As u,v are real coordinates, in the worst case, it will be between 4 integer coordinates of 
% Isrc. We have to find its gray level using the gray levels of the 4 sorrounding pixels =>
% bilinear gray level interpolation.
%  
%
%    g2 +---------------+ g3    
%       |               |
%  v    |     * (u,v) <-|---------------- Isrc coordinates in which the Ides is transformed
%       |               |                 throught H.
%    g0 +---------------+ g1
%               u

floorU = floor(u);
ceilU  = ceil(u);
floorV = floor(v);
ceilV  = ceil(v);   

g0     = zeros(widthR*heightR,1);
g1     = zeros(widthR*heightR,1);
g2     = zeros(widthR*heightR,1);
g3     = zeros(widthR*heightR,1);

l      = find((floorV >= 1) & (floorV < height) & (floorU >= 1) & (floorU < width));
g0(l)  = double(Isrc(floorV(l) + height.*(floorU(l)-1)));
g1(l)  = double(Isrc(floorV(l) + height.*(ceilU(l)-1)));
g2(l)  = double(Isrc(ceilV(l)  + height.*(floorU(l)-1)));
g3(l)  = double(Isrc(ceilV(l)  + height.*(ceilU(l)-1)));

uPrima = (u - floorU);
vPrima = (v - floorV);
g01    = g0 + (g1 - g0).*uPrima;
g23    = g2 + (g3 - g2).*uPrima;
Iresult(y + heightR.*(x-1)) = (g01 + (g23 - g01).*vPrima);

Iresult = uint8(Iresult);


