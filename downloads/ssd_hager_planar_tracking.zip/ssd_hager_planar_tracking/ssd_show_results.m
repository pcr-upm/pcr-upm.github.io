function ssd_show_results(params, width, height, motion_model)
%
%  - width
%  - height
%  - params
%  - motion_model: 'rts', 'affine' or 'projective'
%
% (c) Jos� Miguel Buenaposada, Luis Baumela Molina.
% Please address questions or comments to: jmbuena@dia.fi.upm.es
% Terms of use: You are free to copy,
% distribute, display, and use this work, under the following
% conditions. (1) You must give the original authors credit. (2) You may
% not use or redistribute this work for commercial purposes. (3) You may
% not alter, transform, or build upon this work. (4) For any reuse or
% distribution, you must make clear to others the license terms of this
% work. (5) Any of these conditions can be waived if you get permission
% from the authors.


if (strcmp(motion_model,'traslation')==1)
  
  A = ssd_params_vector2matrix(params ,'traslation');
    
  p1 = [-width/2 -height/2 1]';
  p2 = [ width/2 -height/2 1]';
  p3 = [ width/2  height/2 1]';
  p4 = [-width/2  height/2 1]';

  r1 = A*p1;
  r2 = A*p2;
  r3 = A*p3;
  r4 = A*p4;
  
  r=[r1 r2 r3 r4 r1];
  r = r';
  plot(r(:,1), r(:,2),'-r', ...
       'LineWidth', 4); 
   
elseif (strcmp(motion_model,'rst')==1)
  
  A = ssd_params_vector2matrix(params ,'rst');
    
  p1 = [-width/2 -height/2 1]';
  p2 = [ width/2 -height/2 1]';
  p3 = [ width/2  height/2 1]';
  p4 = [-width/2  height/2 1]';

  r1 = A*p1;
  r2 = A*p2;
  r3 = A*p3;
  r4 = A*p4;
  
  r=[r1 r2 r3 r4 r1];
  r = r';
  plot(r(:,1), r(:,2),'-r', ... 
       'LineWidth', 4); 
  
elseif (strcmp(motion_model,'affine')==1)

  A = ssd_params_vector2matrix(params ,'affine');
     
  p1 = [-width/2 -height/2 1]';
  p2 = [ width/2 -height/2 1]';
  p3 = [ width/2  height/2 1]';
  p4 = [-width/2  height/2 1]';
  
  r1 = A*p1;
  r2 = A*p2;
  r3 = A*p3;
  r4 = A*p4;
  
  r=[r1 r2 r3 r4 r1];
  r = r'; 
  plot(r(:,1), r(:,2),'-r', ...
       'LineWidth', 4); 
  
elseif (strcmp(motion_model,'projective')==1)
  
  H = ssd_params_vector2matrix(params ,'projective');  
    
  p1 = [-width/2 -height/2 1]';
  p2 = [ width/2 -height/2 1]';
  p3 = [ width/2  height/2 1]';
  p4 = [-width/2  height/2 1]';
  
  r1 = H*p1;
  r1 = r1./r1(3,1);
  r2 = H*p2;
  r2 = r2./r2(3,1);
  r3 = H*p3;
  r3 = r3./r3(3,1);
  r4 = H*p4;
  r4 = r4./r4(3,1);
  
  r=[r1 r2 r3 r4 r1];
  r = r'; 
  plot(r(:,1), r(:,2),'-r', ...
       'LineWidth', 4); 
   
else
  error('Motion model not valid');
end
