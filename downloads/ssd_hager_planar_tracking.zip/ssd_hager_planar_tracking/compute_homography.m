function H = compute_homography(width, height, P)
%
% H = compute_homography(width, height, P)
% 
% Given 4 points in P=[x1,y1; x2,y2; x3,y3; x4,y4] and the
% real size (width, height) of the rectagle R, computes the 
% homography between R and the cuadrangle given by P.
%
% (c) Jos� Miguel Buenaposada, Luis Baumela Molina.
% Please address questions or comments to: jmbuena@dia.fi.upm.es
% Terms of use: You are free to copy,
% distribute, display, and use this work, under the following
% conditions. (1) You must give the original authors credit. (2) You may
% not use or redistribute this work for commercial purposes. (3) You may
% not alter, transform, or build upon this work. (4) For any reuse or
% distribution, you must make clear to others the license terms of this
% work. (5) Any of these conditions can be waived if you get permission
% from the authors

x0 = P(1,1);
y0 = P(1,2);
x1 = P(2,1);
y1 = P(2,2);
x2 = P(3,1);
y2 = P(3,2);
x3 = P(4,1);
y3 = P(4,2);

SigmaX  = x0-x1+x2-x3;
SigmaY  = y0-y1+y2-y3;
DeltaX1 = x1-x2;
DeltaY1 = y1-y2;
DeltaX2 = x3-x2;
DeltaY2 = y3-y2;

determinant = (DeltaX1*DeltaY2)-(DeltaX2*DeltaY1);

g = ((SigmaX*DeltaY2)-(DeltaX2*SigmaY))/determinant;
h = ((DeltaX1*SigmaY)-(SigmaX*DeltaY1))/determinant;
a = x1-x0+g*x1;
b = x3-x0+h*x3;
c = y1-y0+g*y1;
d = y3-y0+h*y3;
e = x0;
f = y0;

H1 = [a b e; c d f; g h 1];
S  = [1/width 0 0; 0 1/height, 0; 0 0 1];

H=H1*S;

