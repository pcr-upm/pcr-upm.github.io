function M = ssd_params_vector2matrix(params, motion_model)
%
%  - params
%  - motion_model  : 'rts', 'affine' or 'projective'
%
% (c) Jos� Miguel Buenaposada, Luis Baumela Molina.
% Please address questions or comments to: jmbuena@dia.fi.upm.es
% Terms of use: You are free to copy,
% distribute, display, and use this work, under the following
% conditions. (1) You must give the original authors credit. (2) You may
% not use or redistribute this work for commercial purposes. (3) You may
% not alter, transform, or build upon this work. (4) For any reuse or
% distribution, you must make clear to others the license terms of this
% work. (5) Any of these conditions can be waived if you get permission
% from the authors.


if (strcmp(motion_model,'traslation')==1)

  tx = params(1);  
  ty = params(2);  

  T = [1 0 tx; ...
       0 1 ty; ...
       0 0 1];
 
  M = T;

elseif (strcmp(motion_model,'rst')==1)

  % Stablish the rotation, translation and scale matrix 
  % from params vector.
  % params vector is params = [tx ty r s];
  % and affine is:  
  tx = params(1);  
  ty = params(2);  
  r  = params(3);  
  s  = params(4);  

  R = [cos(r) -sin(r) 0; ...
       sin(r)  cos(r) 0; ...
         0       0    1];
	 
  S = [s 0 0; ...
       0 s 0; ...
       0 0 1];

  T = [1 0 tx; ...
       0 1 ty; ...
       0 0 1];

  M = T*R*S;
  
elseif (strcmp(motion_model,'affine')==1)
            
  % The affine params are, params = [tx ty a b c d];
  % And the affine matrix:
  %
  % A = [a  c  tx; ...
  %      b  d  ty; ...
  %      0  0  1];
  %
  tx  = params(1);
  ty  = params(2);
  a   = params(3);
  c   = params(5);
  d   = params(6);
  b   = params(4);

  M = [a c tx; ...
       b d ty;
       0 0  1];

elseif (strcmp(motion_model,'projective')==1)

   M    = zeros(3,3);
   M(:) = params(:); 
   
else
  error('Motion model not valid');
end
