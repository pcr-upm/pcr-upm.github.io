function ssd_tracking(Itemplate, ...
                      motion_model, ...
                      Pinitial, ...
                      images_info)
%
% Itemplate    - Template Image
% motion_model - 'rst', 'affine' or 'projective'
% PInitial     - The four corners of the object in the first image in [x1 y1; x2 y2, x3 y3; x4 y4] 
%                format.
% imdir        - Dir from which to read the image sequence.
% first_image  - Index of the first image of the sequence.
%
% Important Note: We assume that the template is centered in the origin of coordinates.
%
% (c) Jos� Miguel Buenaposada, Luis Baumela Molina.
% Please address questions or comments to: jmbuena@dia.fi.upm.es
% Terms of use: You are free to copy,
% distribute, display, and use this work, under the following
% conditions. (1) You must give the original authors credit. (2) You may
% not use or redistribute this work for commercial purposes. (3) You may
% not alter, transform, or build upon this work. (4) For any reuse or
% distribution, you must make clear to others the license terms of this
% work. (5) Any of these conditions can be waived if you get permission
% from the authors.

if (isrgb(Itemplate))
   Itemplate = rgb2gray(Itemplate);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Template image histogram equalization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (images_info.equalize)
  Itemplate = histeq(Itemplate);
end
Itemplate = double(Itemplate);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INIT TRACKING 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Mparams    = [];
RESIDUAL   = [];
PARAMS     = [];
INC_PARAMS = [];
NUM_ITERATIONS = [];

width      = size(Itemplate,2);
height     = size(Itemplate,1);
Irectified = zeros(size(Itemplate));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute Initial motion parameters.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vparams    = ssd_compute_initial_params(width, height, Pinitial, motion_model)
Mparams    = ssd_params_vector2matrix(vparams, motion_model)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute Initial Matrices.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M0      = ssd_compute_M0_matrix(Itemplate, motion_model);
for i=1:size(M0,2)
  file_name = sprintf('M0_%d.bmp', i);
  Ii        = vector2image(M0(:,i),size(Itemplate, 2), size(Itemplate, 1));
  imwrite(Ii, gray(256), file_name, 'bmp');
end

if (strcmp(motion_model,'traslation')==1)
  Minitial        = inv(M0'*M0)*M0';  
elseif (strcmp(motion_model,'rst')==1)
  Minitial        = inv(M0'*M0)*M0';  
elseif (strcmp(motion_model,'affine')==1)
  Minitial        = inv(M0'*M0)*M0';  
elseif (strcmp(motion_model,'projective')==1)
  Minitial.M0     = M0;  
  Minitial.M0t_M0 = (M0'*M0);
else
  error('Motion model not valid');  
end

save 'M0.dat' M0 -ascii;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Tracking loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
finish        = 0;
image_index   = images_info.first_image;
htrack        = figure;
set(htrack,'DoubleBuffer','on');
digits_string = sprintf('%d', images_info.file_number_digits);
while (finish==0)   
  image_file = [images_info.imdir '\' images_info.image_prefix sprintf(['%' digits_string '.' digits_string 'd%s'], image_index) images_info.image_postfix '.' images_info.file_extension]
  fid        = fopen(image_file);
  if (fid == -1)
    disp([image_file ' dosen''t found. Ending.']);
    break;
  end
  I          = imread(image_file);
  I2 = I;
  if (isrgb(I2))
    I2         = rgb2gray(I2);
  end
  
  NORM           = 0.2;
  OLD_NORM       = 50000000;
  num_iterations = images_info.max_num_iterations;
  while (num_iterations > 0)         
    % Rectify image
    TR = diag([1 1 1]);
    TR(1,3) = -width/2; 
    TR(2,3) = -height/2;

    % This is necessary because the Warpers do warping taking
    % the pixel (1,1) as the left and top most pixel of the template.
    % So, we have move the (1,1) to the center of the Template.
    M = Mparams*TR;  
      
    Irectified = ssd_warping(I2, Irectified, M, motion_model);
    if (images_info.equalize)
      Irectified = histeq(Irectified);
    end
    Irectified = double(Irectified);
    
    % Compute the error vector
    verror = Irectified(:) - Itemplate(:);
    NORM   = norm(verror)
  
    % Compute the parameter increment
    inc_params     = ssd_compute_vparams_increment(vparams, Minitial, verror, motion_model);
    vparams        = vparams + inc_params;
    Mparams        = ssd_params_vector2matrix(vparams, motion_model);  
    
    if (OLD_NORM - NORM < images_info.max_norm_error_change)
      break;
    end
    OLD_NORM  = NORM;

    num_iterations     = num_iterations - 1;
  end
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Save motion params, increments and residuals
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  if (images_info.save_results)
    PARAMS           = [PARAMS; vparams(:)'];
    INC_PARAMS       = [INC_PARAMS; inc_params(:)'];
    rms              = mean(verror.*verror);
    RESIDUAL         = [RESIDUAL; verror'*verror];
    NUM_ITERATIONS   = [NUM_ITERATIONS; num_iterations];
  
    save 'motion_params.dat' PARAMS -ascii;
    save 'inc_motion_params.dat' INC_PARAMS -ascii;
    save 'residuals.dat' RESIDUAL -ascii;
    save 'num_iterations.dat' NUM_ITERATIONS -ascii;
  end
  
  % Display result
  figure(htrack);
  imshow([I; ones(size(Irectified, 1), size(I, 2) ,3)*255]);
  iptsetpref('ImshowBorder', 'tight');
  hold on;
  imshow(1, size(I, 1)+1, uint8(Irectified));
  imshow(size(Irectified, 2)+1, size(I, 1)+1, uint8(Itemplate));
  ssd_show_results(vparams, width, height, motion_model);  
  hold off;
      
  if (images_info.save_results)
    file_name = sprintf(['%' digits_string '.' digits_string 'd_result.jpg'], image_index);
    eval(['print -djpeg ' file_name]);
  else
    file_name = 'result.jpg';
    eval(['print -djpeg ' file_name]);    
  end
  
  % Next image to read
  image_index = image_index+1;  
end
