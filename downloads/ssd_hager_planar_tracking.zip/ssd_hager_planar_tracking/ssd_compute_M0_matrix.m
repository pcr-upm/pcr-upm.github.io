function M0 = ssd_compute_M0_matrix(I, motion_model)
%
% M0 = ssd_compute_M0_matrix(I, motion_model)
%
% Given the image I and the motion_model computes the 
% Jacobian matrix of I (derivative of I with respect to 
% the motion parameters) to be used in the SSD 'a la Hager'
% tracking.
%
% M0 = dI/dparams
%
% Motion models allowed:
% 'traslation' -
% 'rts'        - Rotation, traslation and scale deformations.
% 'affine'     - Affine deformations of the tracked patch.
% 'projective' - Projective deformations of the tracked patch.
% 
% (c) Jos� Miguel Buenaposada, Luis Baumela Molina.
% Please address questions or comments to: jmbuena@dia.fi.upm.es
% Terms of use: You are free to copy,
% distribute, display, and use this work, under the following
% conditions. (1) You must give the original authors credit. (2) You may
% not use or redistribute this work for commercial purposes. (3) You may
% not alter, transform, or build upon this work. (4) For any reuse or
% distribution, you must make clear to others the license terms of this
% work. (5) Any of these conditions can be waived if you get permission
% from the authors.
%

if (isrgb(I))
  I = rgb2gray(I); 
end

I = double(I);
width  = size(I,2);
height = size(I,1);

motion_model

if (strcmp(motion_model, 'traslation')==1)
   
   [y, x]   = find(I>=0);
   M0       = zeros(width*height, 2);
   [gx, gy] = gradient(I);
   M0(:,1)  = gx(:);
   M0(:,2)  = gy(:);
   M0       = double(M0);

elseif (strcmp(motion_model, 'rst')==1)
   
   [y, x]   = find(I>=0);
   M0       = zeros(width*height, 4);
   [gx, gy] = gradient(I);
   xw2      = x-(width/2);
   yh2      = y-(height/2);
   M0(:,1)  = gx(:);
   M0(:,2)  = gy(:);
   M0(:,3)  = gx(:).*(-yh2) + gy(:).* xw2;
   M0(:,4)  = gx(:).*(xw2) + gy(:).* yh2;
   M0       = double(M0);
      
elseif (strcmp(motion_model,'affine')==1)
   
   [y, x]   = find(I>=0);
   M0       = zeros(width*height, 6);
   [gx, gy] = gradient(I);
   xw2      = x-(width/2);
   yh2      = y-(height/2);
   M0(:,1)  = gx(:);
   M0(:,2)  = gy(:);
   M0(:,3)  = gx(:) .* xw2;
   M0(:,4)  = gy(:) .* xw2;
   M0(:,5)  = gx(:) .* yh2;
   M0(:,6)  = gy(:) .* yh2;   
   M0       = double(M0);

elseif (strcmp(motion_model,'projective')==1)
   
   [y, x]   = find(I>=0);
   M0       = zeros(width*height, 9);
   [gx, gy] = gradient(I);
   xw2      = x-(width/2);
   yh2      = y-(height/2);
   gxy      = -((gx(:) .* xw2) +  (gy(:) .* yh2)); 
   M0(:,1)  = gx(:) .* xw2;
   M0(:,2)  = gy(:) .* xw2;
   M0(:,3)  = gxy .* xw2;
   M0(:,4)  = gx(:) .* yh2;
   M0(:,5)  = gy(:) .* yh2;
   M0(:,6)  = gxy.* yh2;
   M0(:,7)  = gx(:);
   M0(:,8)  = gy(:);
   M0       = double(M0);
   
else
   error('motion model not supported');
end
