

%
% The corresponding points needs this order:
%
% 1 +---------+ 2
%   |         |
%   |         |
%   |         |
% 4 +---------+ 3
%
Pinitial                          = [69 68; 213 69; 214 142; 69 143];
images_info.equalize              = 0;
images_info.save_results          = 0;
images_info.max_num_iterations    = 10;
images_info.max_norm_error_change = 0.001;
images_info.imdir                 = '.\plantilla_calib_ajedrez_en_mano_3_320x240'; 
images_info.first_image           = 60;
images_info.image_prefix          = 'test-';
images_info.image_postfix         = '';
%motion_model                     = 'traslation';
%motion_model                     = 'affine';
motion_model                      = 'projective';
%motion_model                     = 'rst';
Itemplate                         = imread('.\plantilla_calib_ajedrez_en_mano_3_320x240\ssd_template_tiny.bmp');
images_info.file_number_digits    = 10;
images_info.file_extension        = 'jpg';


ssd_tracking(Itemplate, ...
             motion_model, ...
             Pinitial, ...
             images_info);

