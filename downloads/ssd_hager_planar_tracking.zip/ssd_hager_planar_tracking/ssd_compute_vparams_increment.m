function params_inc = ssd_compute_vparams_increment(current_params, ...
                                                    initial_matrix, ...
						    verror, ...
						    motion_model)
%
%  - current_params
%  - initial_matrix
%  - verror
%  - motion_model  : 'rts', 'affine' or 'projective'
%
% (c) Jos� Miguel Buenaposada, Luis Baumela Molina.
% Please address questions or comments to: jmbuena@dia.fi.upm.es
% Terms of use: You are free to copy,
% distribute, display, and use this work, under the following
% conditions. (1) You must give the original authors credit. (2) You may
% not use or redistribute this work for commercial purposes. (3) You may
% not alter, transform, or build upon this work. (4) For any reuse or
% distribution, you must make clear to others the license terms of this
% work. (5) Any of these conditions can be waived if you get permission
% from the authors.


if (strcmp(motion_model,'traslation')==1)

  params_inc = -initial_matrix*verror;
  
elseif (strcmp(motion_model,'rst')==1)
    
  tx = current_params(1);  
  ty = current_params(2);  
  r  = current_params(3);  
  s  = current_params(4);  

  Sigma = [1/s*cos(-r) -1/s*sin(-r)  0   0; ...
           1/s*sin(-r)  1/s*cos(-r)  0   0; ...
              0           0          1   0; ...
              0           0          0  1/s];
	      
  params_inc = -inv(Sigma)*initial_matrix*verror;
  
elseif (strcmp(motion_model,'affine')==1)

  % The affine params are, params = [tx ty a b c d];
  % And the affine matrix:
  %
  % A = [a  c  tx; ...
  %      b  d  ty; ...
  %      0  0  1];
  %
  a = current_params(3);
  c = current_params(5);
  d = current_params(6);
  b = current_params(4);

  A = [a c; ...
       b d];

  invA            = inv(A);
  
  Sigma           = zeros(6,6);
  Sigma(1:2, 1:2) = invA;
  Sigma(3:4, 3:4) = invA;
  Sigma(5:6, 5:6) = invA;
  
  params_inc      = -inv(Sigma)*initial_matrix*verror;
  params_inc      = -initial_matrix*verror;
  
elseif (strcmp(motion_model,'projective')==1)

  Sigma           = zeros(9,8);
  H               = zeros(3,3);
  H(:)            = current_params(:);
  invH            = inv(H);    
  Sigma(1:3,1:3)  = invH;
  Sigma(4:6,4:6)  = invH;
  Sigma(7:9,7:8)  = invH(1:3,1:2);

  M0t_M0         = initial_matrix.M0t_M0;
  M0             = initial_matrix.M0;
  
  params_inc     = -inv(Sigma'*M0t_M0*Sigma)*Sigma'*M0'*verror;
  params_inc     = [params_inc; 0];
  
else
  error('Motion model not valid');
end

