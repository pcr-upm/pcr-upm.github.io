

#ifndef _CV_FINDHOMOGRAPHY_H_
#define _CV_FINDHOMOGRAPHY_H_

#include <opencv/cv.h>

namespace ransac_test {
  int
  cvFindHomography( const CvMat* objectPoints, const CvMat* imagePoints,
                    CvMat* __H, int method, double ransacReprojThreshold,
                    CvMat* mask,
		    bool use_geometrical_constraint);
}; // namespace ransac_test

#endif