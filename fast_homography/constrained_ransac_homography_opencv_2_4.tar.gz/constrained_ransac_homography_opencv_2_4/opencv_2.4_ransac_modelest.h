
#ifndef _CV_MODEL_EST_H_
#define _CV_MODEL_EST_H_

#include <opencv/cv.h>

namespace ransac_test {
  
class CvHomographyEstimator
{
public:
    CvHomographyEstimator(int _modelPoints );
    virtual ~CvHomographyEstimator();

    virtual int runKernel( const CvMat* m1, const CvMat* m2, CvMat* model );
//     virtual bool runLMeDS( const CvMat* m1, const CvMat* m2, CvMat* model,
//                            CvMat* mask, double confidence=0.99, int maxIters=2000 );
    virtual bool runRANSAC( const CvMat* m1, const CvMat* m2, CvMat* model,
                            CvMat* mask, double threshold,
                            double confidence=0.99, int maxIters=2000,
			    bool use_geometrical_constraint = true );

    virtual bool refine( const CvMat*, const CvMat*, CvMat*, int );
    virtual void setSeed( int64 seed );

protected:
    virtual void computeReprojError( const CvMat* m1, const CvMat* m2,
                                     const CvMat* model, CvMat* error );
    virtual int findInliers( const CvMat* m1, const CvMat* m2,
                             const CvMat* model, CvMat* error,
                             CvMat* mask, double threshold );
    virtual bool getSubset( const CvMat* m1, const CvMat* m2,
                            CvMat* ms1, CvMat* ms2, int maxAttempts=1000 );
    virtual bool checkSubset( const CvMat* ms1, int count );
    virtual bool isMinimalSetConsistent( const CvMat* m1, const CvMat* m2 );

    CvRNG rng;
    int modelPoints;
    CvSize modelSize;
    int maxBasicSolutions;
    bool checkPartialSubsets;
};
}

#endif // _CV_MODEL_EST_H_

